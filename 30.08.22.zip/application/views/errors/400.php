<h1>Error 403 - Forbidden</h1>
<hr>
<p>Sorry, you are not allowed to be here!</p>
<p>Try logging in first</p>
<script type="text/javascript">
	function func()
	{
		window.location = '/';
	}
	setTimeout(func,2000);
</script>