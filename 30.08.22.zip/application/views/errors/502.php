<p>
<h1>Error 502</h1>
</p>
<hr>
<p>Connection to the database failed</p>
<p style="color: transparent">Check /application/config/db.php</p>
