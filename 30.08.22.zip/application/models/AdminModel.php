<?php

namespace application\models;

use application\core\Model;

class AdminModel extends Model{

}