<?php

namespace application\models;

use application\core\Model;

class MainModel extends Model{
	
	
}
