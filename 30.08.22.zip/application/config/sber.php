<?php

return [
    'host' => 'https://3dsec.sberbank.ru/',                  //тестовый хост
    //'host' => 'https://securepayments.sberbank.ru/',       //боевой хост
    'username' => 'leosmagin-api',
    'password' => 'leosmagin',
    'ApiToken' => '4issip2qjg536cdlak8bu93fp3',
    'secretKey' => ''

];
