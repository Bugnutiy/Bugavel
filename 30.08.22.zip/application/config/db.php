<?php
// dd($_SERVER);
return [
	'host' => 'h902111921.mysql',
	'name' => 'h902111921_leosnew',
	'user' => 'h902111921_leonw',
	'password' => 'y2+tSZaE',
	'charset' => 'utf8mb4',//unicode_ci
];
