<?php

return
    [
        'all' => [
            'lang',
            'contacts',
            'news',
            'confident',
        ],

        'authorize' => [
            //
        ],

        'guest' => [
            //
        ],

        'admin' => [
            
        ],
    ];
