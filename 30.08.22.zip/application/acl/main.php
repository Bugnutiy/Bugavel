<?php

return
    [
        'all' => [
            'index',
            'catalog',
            'product',
            'cart',
            'order',
            'policy',
            'contacts',
            'payment',
            'delivery',
        ],

        'authorize' => [
            //
        ],

        'guest' => [
            //
        ],

        'admin' => [],
    ];
