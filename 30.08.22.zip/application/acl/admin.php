<?php

return
    [
        'all' => [],

        'authorize' => [
            //
        ],

        'guest' => [
            //
        ],

        'admin' => [
            //
            'test',
            'main',
            'categories',
            'categoriesEdit',
            'categoriesDelete',
            'products',
            'productsEdit',
            'productsDelete',
            'properties',
            'propertiesEdit',
            'propertiesDelete',
            'orders',
            'ordersEdit',
            'sber',
            'coredb',
        ],
    ];
