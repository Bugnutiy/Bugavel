<?php
return [
	'host' => 'h902111921.mysql',
	'name' => 'h902111921_leosnew',
	'user' => 'h902111921_leonw',
	'password' => 'y2+tSZaE',
	'charset' => 'utf8mb4',//unicode_ci
];

// return [
// 	'host' => '127.0.0.1',
// 	'name' => 'leosnew',
// 	'user' => 'LeosNew',
// 	'password' => 'poilka170196',
// 	'charset' => 'utf8mb4',//unicode_ci
// ];
