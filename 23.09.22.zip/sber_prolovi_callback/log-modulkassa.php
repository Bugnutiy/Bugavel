
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-08 18:49:06
Request: https://service.modulpos.ru/api/fn/v1/associate/f13ce068-dde0-4149-ab80-349e5e47ea69
Array
(
)

Response: {"userName":"5c5e25fb-6740-4942-9166-0d77b285b60a","password":"hj5C9P2FdiFusOhM","name":"Магазин","address":"143986, Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-08 18:49:07
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => d21a0523-6749-4adf-8f3d-e48d3bfbc0e1
    [docNum] => 198002
    [docType] => SALE
    [checkoutDateTime] => 2022-08-08T21:49:06+03:00
    [email] => nickkarpan@gmail.com
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Тестовый тест
                    [price] => 1
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 1
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-08T18:49:06+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-08 18:55:14
Request: https://service.modulpos.ru/api/fn/v1/associate/f13ce068-dde0-4149-ab80-349e5e47ea69
Array
(
)

Response: {"userName":"5c5e25fb-6740-4942-9166-0d77b285b60a","password":"KnjNyOnX8EkTqHIZ","name":"Магазин","address":"143986, Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-08 18:55:15
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => e54bd8af-6a6e-4814-96c4-7cd13195e474
    [docNum] => 197002
    [docType] => SALE
    [checkoutDateTime] => 2022-08-08T21:55:14+03:00
    [email] => nickkarpan@gmail.com
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Тестовый тест для тестирования
                    [price] => 1
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 1
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-08T18:55:15+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-08 19:26:50
Request: https://service.modulpos.ru/api/fn/v1/associate/f13ce068-dde0-4149-ab80-349e5e47ea69
Array
(
)

Response: {"userName":"5c5e25fb-6740-4942-9166-0d77b285b60a","password":"srqNgxth6rbuweQB","name":"Магазин","address":"143986, Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-08 19:26:51
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 60a4e588-9668-4082-b3fe-bb5c4f5a98fb
    [docNum] => 197003
    [docType] => SALE
    [checkoutDateTime] => 2022-08-08T22:26:50+03:00
    [email] => nickkarpan@gmail.com
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Фанатика
                    [price] => 40000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 40000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-08T19:26:51+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-09 08:22:24
Request: https://service.modulpos.ru/api/fn/v1/associate/f13ce068-dde0-4149-ab80-349e5e47ea69
Array
(
)

Response: {"userName":"5c5e25fb-6740-4942-9166-0d77b285b60a","password":"zbHrCiPAsbfe7RHW","name":"Магазин","address":"143986, Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-09 08:22:25
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 2c6d24e1-d2d8-4914-8ffd-3e6e00b605d1
    [docNum] => 196005
    [docType] => SALE
    [checkoutDateTime] => 2022-08-09T11:22:24+03:00
    [email] => nickkarpan@gmail.com
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Рей
                    [price] => 45000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 45000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-09T08:22:25+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-11 12:53:07
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"WfSiBBkDvj1Xu7MJ","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-11 12:53:07
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => b34748d2-0fc4-4c6f-8071-91a23ce74bb5
    [docNum] => 
    [docType] => SALE
    [checkoutDateTime] => 2022-08-11T15:53:07+03:00
    [email] => nickkarpan@gmail.com
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => 
                    [price] => 0
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 0
                )

        )

)

Response: {"timestamp":"2022-08-11T09:53:07+00:00","status":400,"error":"Bad Request","errors":[{"objectName":"documentDTO","field":"docNum","rejectedValue":null,"defaultMessage":"Номер документа обязателен","code":"NotBlank"},{"objectName":"documentDTO","field":"inventPositions[0].name","rejectedValue":"","defaultMessage":"Наименование товара обязательно","code":"NotBlank"}],"message":"Validation failed for object='documentDTO'. Error count: 2","path":"/fn/v1/doc"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-11 12:54:49
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"hccF4JxZHI0WFKGe","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-11 12:54:49
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => db9d3f0f-9ada-46ea-990f-c930f6bdde43
    [docNum] => 201000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-11T15:54:49+03:00
    [email] => nickkarpan@gmail.com
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Тест
                    [price] => 1
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 1
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-11T09:54:49+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-11 13:10:13
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"fvRDDqDvCiimYF4W","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-11 13:10:13
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 799d38d8-2fc9-4e0f-bed2-da9bd9ee68a5
    [docNum] => 202000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-11T16:10:13+03:00
    [email] => nickkarpan@gmail.com
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => А.Тхир_Lovi+шнур+4фротопл
                    [price] => 47200
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 47200
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-11T10:10:13+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-13 16:28:53
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"BTzlkrZiXXhG1ZoH","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-13 16:28:54
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => fa90a98d-968a-43d6-aab8-fbc8436f7ff7
    [docNum] => 203000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-13T19:28:53+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Гусарова
                    [price] => 900
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 900
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-13T13:28:54+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-14 18:40:22
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"DHjolOfBIDABub4S","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-14 18:40:23
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 4c81e3b3-1870-4cb5-b193-ef17e0a8d19a
    [docNum] => 201002
    [docType] => SALE
    [checkoutDateTime] => 2022-08-14T21:40:22+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Filimonova
                    [price] => 16500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 16500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-14T15:40:23+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-14 19:47:59
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"b9f97y07y1kyGbRr","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-14 19:47:59
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => c8db17d9-ef69-4e7b-ab8c-4b69fd1d3c3c
    [docNum] => 203001
    [docType] => SALE
    [checkoutDateTime] => 2022-08-14T22:47:59+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шиханова
                    [price] => 15000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 15000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-14T16:47:59+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-15 14:10:04
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"tJL0gq4jA6OzfNUW","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-15 14:10:04
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => ba0a6850-058d-47f9-af51-32c6edd21d98
    [docNum] => 204002
    [docType] => SALE
    [checkoutDateTime] => 2022-08-15T17:10:04+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => GURU, переходник ал 16
                    [price] => 19500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 19500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-15T11:10:04+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-17 13:40:02
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"FNgSnVUnNPfDQmzK","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-17 13:40:02
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => c84efdff-bd3e-4165-9299-49acdacf900d
    [docNum] => 205000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-17T16:40:02+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => GURU, фторопл бел 3
                    [price] => 16200
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 16200
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-17T10:40:02+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-17 18:56:26
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"KasSYhUpPEhHGjfc","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-17 18:56:26
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => e321ce63-a290-4b19-baaf-3d754aa4c485
    [docNum] => 205001
    [docType] => SALE
    [checkoutDateTime] => 2022-08-17T21:56:26+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур Лови
                    [price] => 2000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-17T15:56:26+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-18 15:46:34
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"ZlwHSgKWem66AFRw","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-18 15:46:34
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 5dab221d-ae97-4719-adf1-fd8708646379
    [docNum] => 206000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-18T18:46:34+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур Lovi,G, R
                    [price] => 2000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-18T12:46:34+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-19 07:31:28
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"IVf8sPtCb8FnjNlp","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-19 07:31:29
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => bbb9b2af-22ad-4d14-92ca-6e4bfaf99c14
    [docNum] => 207000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-19T10:31:28+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => REY, Хелпер д16, грометсы, резинки
                    [price] => 51000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 51000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-19T04:31:29+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-19 15:38:20
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"rBHE5pBi1sDBZq3G","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-19 15:38:20
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => bc680ffe-5606-4320-a020-62099276d398
    [docNum] => 208000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-19T18:38:20+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Описание для клиента
                    [price] => 1
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 1
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-19T12:38:20+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-21 17:22:49
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"SVqqC7LUmLuRW5pb","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-21 17:22:50
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => dc5b9a02-619e-4d53-9be5-d9998e7f1c45
    [docNum] => 208001
    [docType] => SALE
    [checkoutDateTime] => 2022-08-21T20:22:49+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Бар
                    [price] => 2000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-21T14:22:49+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-21 19:18:24
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"tdOBGcs3MwCir6rA","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-21 19:18:24
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => e1618d62-d42c-4d9a-9821-c2a28be988a7
    [docNum] => 207001
    [docType] => SALE
    [checkoutDateTime] => 2022-08-21T22:18:24+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Guru_Новинская
                    [price] => 15000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 15000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-21T16:18:24+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-22 06:15:14
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"Wm9lQFHoBhx0ZmNp","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-22 06:15:14
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 1100ce40-a67f-403f-8534-c3b631a4556a
    [docNum] => 209000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-22T09:15:14+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур Lovi
                    [price] => 2000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-22T03:15:14+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-22 09:55:57
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"ZgNfVBfSjdhaxseQ","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-22 09:55:57
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 96f39398-a445-4667-9e04-8be134d258a8
    [docNum] => 209001
    [docType] => SALE
    [checkoutDateTime] => 2022-08-22T12:55:57+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Резинки
                    [price] => 500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-22T06:55:57+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-22 16:06:48
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"NqCpTByoLNzTsO7S","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-22 16:06:49
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 03dbd8a3-a832-48f4-b015-fba256b78e3e
    [docNum] => 208002
    [docType] => SALE
    [checkoutDateTime] => 2022-08-22T19:06:48+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Guru, резинки, толкатель
                    [price] => 15650
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 15650
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-22T13:06:49+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-22 21:25:08
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"WIwGIeWOZSBGL6Qr","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-22 21:25:08
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 67a9c538-3c73-4594-bf1b-1a7c23428b62
    [docNum] => 210000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-23T00:25:08+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Цанга, ключ 1.5, Шнур Л, Хепл д18
                    [price] => 7500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 7500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-22T18:25:08+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-23 08:50:22
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"zk2AWr1yDmsRc3gn","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-23 08:50:22
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 053d1ffb-b412-47a5-9e2c-2ace5895c442
    [docNum] => 211000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-23T11:50:22+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Хелпер
                    [price] => 5000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 5000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-23T05:50:22+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-23 18:10:57
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"XnzcXKrXX9Aq3Ygn","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-23 18:10:57
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => b7ad203e-ca60-4b4e-ab45-676f2d3cae5e
    [docNum] => 212000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-23T21:10:57+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => ALTERA
                    [price] => 21000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 21000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-23T15:10:57+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-24 08:39:45
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"XPtRa2Yj0EigByuk","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-24 08:39:45
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 346fb2f4-7dda-46e2-b20c-7498a43db3f0
    [docNum] => 213000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-24T11:39:45+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => 1R0.3, резинки
                    [price] => 3500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 3500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-24T05:39:45+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-24 16:43:06
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"DLbUEuJJYvha5bZt","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-24 16:43:06
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 316d69e5-d05d-47b6-bf19-7fcfd36cb8bb
    [docNum] => 212001
    [docType] => SALE
    [checkoutDateTime] => 2022-08-24T19:43:06+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур ЛОви х4
                    [price] => 6500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 6500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-24T13:43:06+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-25 13:28:28
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"VRbg6RwN5YQP08QV","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-25 13:28:28
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => e01eefaf-83db-4e24-a89e-ceb56306dd7d
    [docNum] => 214000
    [docType] => SALE
    [checkoutDateTime] => 2022-08-25T16:28:28+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур Лови
                    [price] => 2000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-25T10:28:28+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-25 22:13:32
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"8LkIlbRaWJEbrrCD","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-25 22:13:32
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 35c56fdd-4fc3-4f9e-8222-1c7800fccfe3
    [docNum] => 213001
    [docType] => SALE
    [checkoutDateTime] => 2022-08-26T01:13:32+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Guru
                    [price] => 24150
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 24150
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-25T19:13:32+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-26 17:59:41
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"w0ZbolGFZHugUS48","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-08-26 17:59:41
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => d9cd65de-d643-4e87-879a-8549420efad3
    [docNum] => 212002
    [docType] => SALE
    [checkoutDateTime] => 2022-08-26T20:59:41+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Фторопласт черн
                    [price] => 1600
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 1600
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-08-26T14:59:41+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-13 15:02:23
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"6beS4hypHB2Ow9pl","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-13 15:02:23
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 3486a561-3e0a-474e-84bb-8c3b40291924
    [docNum] => 222000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-13T18:02:23+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Фторопласт белый - 10 шт
                    [price] => 4000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 4000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-13T12:02:23+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-13 18:53:32
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"Ml8o0PiGkBPGqDlN","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-13 18:53:32
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 44d6e079-a79f-4266-aebe-53c7539bbc75
    [docNum] => 223000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-13T21:53:32+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур Lovi, резинки
                    [price] => 2500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-13T15:53:32+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-14 19:06:10
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"SXat9xcVeB6t2uOS","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-14 19:06:10
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => ddd2b2d7-a6e2-470e-aab0-1afc624a1905
    [docNum] => 224000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-14T22:06:10+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Машинка GURU
Переходник под картриджи
Сменный эксцентрик с ходом 2,5мм 
                    [price] => 22500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 22500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-14T16:06:10+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-15 15:47:14
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"o4SJo5OOUpZnTehT","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-15 15:47:14
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => b1128ddb-5e4f-4b11-b071-1302983daa1c
    [docNum] => 225000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-15T18:47:14+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Заказ № 1931172538
Tattoo helper диаметр держателя 16mm - 
5000 руб/шт  х 3 шт =15000 руб Шнур питания Lovi, Guru , Ray - 2000 руб
                    [price] => 17000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 17000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-15T12:47:14+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-16 02:39:39
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"20CQIYtb4wzQ55SB","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-16 02:39:39
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 1fc56cb5-1adc-470d-8185-1554e18fb44e
    [docNum] => 226000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-16T05:39:39+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Фторопласт черный 2шт
                    [price] => 1600
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 1600
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-15T23:39:39+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-16 18:39:46
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"R0gx7lVXSyOMOtQa","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-16 18:39:46
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 3cb61a33-dbc1-439a-86bb-e97fec85e299
    [docNum] => 227000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-16T21:39:46+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Эксцентрик Гуру 2.5 мм
                    [price] => 3500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 3500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-16T15:39:46+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-18 19:19:01
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"gOi7NsKBio9E8KFu","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-18 19:19:01
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => efb1c44c-fd9b-4d9e-ba69-1a8673480c57
    [docNum] => 227001
    [docType] => SALE
    [checkoutDateTime] => 2022-09-18T22:19:01+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Фторопласт бел - 2шт, резинки
                    [price] => 1300
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 1300
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-18T16:19:01+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-18 20:30:02
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"QNfaAusF822taLob","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-18 20:30:02
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => e23826da-0ddf-4878-8388-0f702d3da587
    [docNum] => 226001
    [docType] => SALE
    [checkoutDateTime] => 2022-09-18T23:30:02+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Хелпер д18, Фторопласт черн - 2 шт
                    [price] => 6600
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 6600
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-18T17:30:02+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-19 14:59:15
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"CyavihAgp4SlAaT2","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-19 14:59:15
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 9ed966cd-c502-405b-b46d-0a0e2c090b67
    [docNum] => 227002
    [docType] => SALE
    [checkoutDateTime] => 2022-09-19T17:59:15+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Guru
                    [price] => 15000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 15000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-19T11:59:15+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-19 17:04:22
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"kFEKLuapl0yunmlA","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-19 17:04:23
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 594b61f8-82e8-4b91-836c-c18b634e252e
    [docNum] => 227003
    [docType] => SALE
    [checkoutDateTime] => 2022-09-19T20:04:22+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Машинка Guru, переходник титан, эксцентрик 2.5мм
                    [price] => 24000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 24000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-19T14:04:22+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-19 22:52:16
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"fSzlNJFfrvGJ5wpB","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-19 22:52:16
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 2eed3fa9-41a7-44a6-a638-86bb7b6074e6
    [docNum] => 228000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-20T01:52:16+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Rotary gold 
                    [price] => 20000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 20000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-19T19:52:16+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-20 10:35:36
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"hIA5wCbmvvNccz7D","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-20 10:35:36
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 1247ccd7-6beb-4a87-a663-3d1b088bbbc7
    [docNum] => 228001
    [docType] => SALE
    [checkoutDateTime] => 2022-09-20T13:35:36+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур Лови, Фторопласт черн - 1шт
                    [price] => 2800
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2800
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-20T07:35:36+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-20 12:22:15
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"tNb4X7hFs8eZ5Gfi","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-20 12:22:15
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => 6782163c-62a0-4546-9c33-25b7815264bb
    [docNum] => 229000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-20T15:22:15+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Шнур Лови
                    [price] => 2000
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 2000
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-20T09:22:15+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-20 15:13:14
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"M80Lk3bAlVcLcq1o","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-20 15:13:15
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => ed59bf25-7f3c-45d5-9728-5d9bf4a23c1a
    [docNum] => 229001
    [docType] => SALE
    [checkoutDateTime] => 2022-09-20T18:13:14+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => дост
                    [price] => 410
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 410
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-20T12:13:15+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-20 15:56:33
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"VBzJ8LrmOUoghoQa","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-20 15:56:33
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => e25d24a0-ad88-40ec-813a-1f2404b027c2
    [docNum] => 227004
    [docType] => SALE
    [checkoutDateTime] => 2022-09-20T18:56:33+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Переходник титан д16, грометсы, резинки
                    [price] => 6500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 6500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-20T12:56:33+00:00"}


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-09-21 18:47:17
Request: https://service.modulpos.ru/api/fn/v1/associate/b017e1d9-e0da-4616-8047-29bdabd20478
Array
(
)

Response: {"userName":"8c9de509-8869-4c68-a863-a1f252fcff7a","password":"32jpE5KYYAb9LzCP","name":"Студия татуажа LeOks","address":"Московская обл, г Балашиха, мкр Железнодорожный, ул Пионерская, д 14Б"}


Date: 2022-09-21 18:47:17
Request: https://service.modulpos.ru/api/fn/v1/doc
Array
(
    [id] => e8b9a748-f240-4e40-ae2e-0e1faa7f83d4
    [docNum] => 230000
    [docType] => SALE
    [checkoutDateTime] => 2022-09-21T21:47:17+03:00
    [email] => info@prolovi.ru
    [taxMode] => 
    [inventPositions] => Array
        (
            [0] => Array
                (
                    [name] => Переходник алюминий д16
                    [price] => 4500
                    [quantity] => 1
                    [vatTag] => 1105
                )

        )

    [moneyPositions] => Array
        (
            [0] => Array
                (
                    [paymentType] => CARD
                    [sum] => 4500
                )

        )

)

Response: {"status":"QUEUED","fnState":"ASSOCIATED","fiscalInfo":null,"failureInfo":null,"message":"Document queued for printing","timeStatusChanged":"2022-09-21T15:47:17+00:00"}

