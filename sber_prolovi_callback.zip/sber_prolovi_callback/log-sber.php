=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-08 14:29:09

Array
(
)

Array
(
    [date] => 08.08.2022+17%3A28%3A50
    [merchantLogin] => prolovi
    [approvalCode] => 261505
    [orderNumber] => 196004
    [approvedAmountFormatted] => 1.00
    [depositedAmountFormatted] => 1.00
    [bankName] => Sberbank
    [eci] => 02
    [terminalId] => 21129642
    [mdOrder] => 384a98cd-1869-7163-a4ea-5b8f01edca78
    [orderDescription] => %D0%A2%D0%B5%D1%81%D1%82
    [amountFormatted] => 1.00
    [merchantFullName] => prolovi.ru
    [currencyName] => RUB
    [processingId] => 851000051248
    [checksum] => 025214DDD933C9CDE4EE2E04A1BA714770F632A73A3AB40F8CB2DA7FAE446EC3
    [paymentRefNum] => 222087835722
    [currency] => 643
    [approvedAmount] => 100
    [expiry] => 202209
    [paymentState] => payment_deposited
    [amount] => 100
    [maskedPan] => 533669XXXXXX9048
    [panCountryCode] => RU
    [depositedAmount] => 100
    [ip] => 95.73.52.27
    [ipCountryCode] => RU
    [panMasked] => 533669XXXXXX9048
    [depositFlag] => 1
    [paymentWay] => CARD
    [refNum] => 222087835722
    [cardholderName] => CARD+HOLDER
    [paymentDate] => 08.08.2022+17%3A29%3A04
    [refundedAmountFormatted] => 0.00
    [operation] => deposited
    [merchantUrl] => http%3A%2F%2Fprolovi.ru%2F
    [refundedAmount] => 0
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 1fe4640701aef5200de7d8eb3403ce66e01a13579b291ea517b39cc98b463939
Date: 2022-08-08 18:23:14

Array
(
)

Array
(
    [amount] => 100
    [orderNumber] => 197001
    [checksum] => FE13DD3E468EECE6FEF77703911EEB8671167FFB6E7C808910342C0D67FCC9C9
    [mdOrder] => ad5dab45-1665-7550-95f6-27f601edca78
    [orderDescription] => %D0%A2%D0%B5%D1%81%D1%82
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: c779edca3cb0a362926258d25de24171e3eb7fa08955bd8ae4b4bc4b31b65c0e
Date: 2022-08-08 18:36:05

Array
(
)

Array
(
    [amount] => 100
    [orderNumber] => 198001
    [checksum] => C779EDCA3CB0A362926258D25DE24171E3EB7FA08955BD8AE4B4BC4B31B65C0E
    [mdOrder] => b56a433a-d4b6-70db-a2a1-dffb01edca78
    [orderDescription] => %D0%A2%D0%B5%D1%81%D1%82+2
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-08 18:49:07

Array
(
    [amount] => 100
    [orderNumber] => 198002
    [checksum] => 114912E5841223D308459EC7EC52C6EED858E004E22F07FA0EC5A1CCA878678A
    [mdOrder] => 8f06a093-40bd-7be6-9459-e3dd01edca78
    [orderDescription] => %D0%A2%D0%B5%D1%81%D1%82%D0%BE%D0%B2%D1%8B%D0%B9+%D1%82%D0%B5%D1%81%D1%82
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-08 18:55:15

Array
(
    [amount] => 100
    [orderNumber] => 197002
    [checksum] => FCF6A828DE6A25A9EC72A257B4A6D51B5527F7F84DF6D1BBCEC5B46F41D6CECF
    [mdOrder] => 8169d6f7-883d-7f3f-856b-2c5701edca78
    [orderDescription] => %D0%A2%D0%B5%D1%81%D1%82%D0%BE%D0%B2%D1%8B%D0%B9+%D1%82%D0%B5%D1%81%D1%82+%D0%B4%D0%BB%D1%8F+%D1%82%D0%B5%D1%81%D1%82%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-08 19:26:51

Array
(
    [amount] => 4000000
    [orderNumber] => 197003
    [checksum] => 0A73A24B383AC66408127EDB8807F236A528CE591F50CC58E68A3B37EB0212BF
    [mdOrder] => 364ffe29-9bbe-7b1f-8a39-f7e101edca78
    [orderDescription] => %D0%A4%D0%B0%D0%BD%D0%B0%D1%82%D0%B8%D0%BA%D0%B0
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Date: 2022-08-09 08:22:25

Array
(
    [amount] => 4500000
    [orderNumber] => 196005
    [checksum] => 5452876AAE31AB095768D310EF9040D4A51039B9B474F41284B4A57E123CCB00
    [mdOrder] => dd966a7a-b6a0-754d-9fb4-82ff01edca78
    [orderDescription] => %D0%A0%D0%B5%D0%B9
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 
Date: 2022-08-11 12:53:07

Array
(
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: d61f58d78a820a644095293294740bfa0c4f0d326545b9d4b05cdb439d97e87a
Date: 2022-08-11 12:54:49

Array
(
    [amount] => 100
    [orderNumber] => 201000
    [checksum] => D61F58D78A820A644095293294740BFA0C4F0D326545B9D4B05CDB439D97E87A
    [mdOrder] => c5db3bc7-ebeb-75bb-8bd2-116f01edca78
    [orderDescription] => %D0%A2%D0%B5%D1%81%D1%82
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: c7deb83cbb6fb3b486c67cbc69901ac83ccf5a6a13f17c52cde6f418561bfa10
Date: 2022-08-11 13:10:13

Array
(
    [amount] => 4720000
    [orderNumber] => 202000
    [checksum] => C7DEB83CBB6FB3B486C67CBC69901AC83CCF5A6A13F17C52CDE6F418561BFA10
    [mdOrder] => 80b44689-32d8-7bf7-ae3f-2abc01edca78
    [orderDescription] => %D0%90.%D0%A2%D1%85%D0%B8%D1%80_Lovi%2B%D1%88%D0%BD%D1%83%D1%80%2B4%D1%84%D1%80%D0%BE%D1%82%D0%BE%D0%BF%D0%BB
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: acfc63468f4221142119c146a5285cdb8836596afb1394497cfaa4070027c4e2
Date: 2022-08-13 16:28:54

Array
(
    [amount] => 90000
    [orderNumber] => 203000
    [checksum] => ACFC63468F4221142119C146A5285CDB8836596AFB1394497CFAA4070027C4E2
    [mdOrder] => 1a801820-23d4-7b62-a594-9fc101edca78
    [orderDescription] => %D0%93%D1%83%D1%81%D0%B0%D1%80%D0%BE%D0%B2%D0%B0
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 2522ba13e1dae1b41030a21960fe1f24b353a3496955bfa6db6a5ed5c3aa469e
Date: 2022-08-14 18:40:23

Array
(
    [amount] => 1650000
    [orderNumber] => 201002
    [checksum] => 2522BA13E1DAE1B41030A21960FE1F24B353A3496955BFA6DB6A5ED5C3AA469E
    [mdOrder] => b3bc769f-c47b-7ce8-8e65-275001edca78
    [orderDescription] => Filimonova
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 1267804d8c66c161ead559cb290cf6ef6fd6f6f7ea861135c021a35fd26b6c79
Date: 2022-08-14 19:47:59

Array
(
    [amount] => 1500000
    [orderNumber] => 203001
    [checksum] => 1267804D8C66C161EAD559CB290CF6EF6FD6F6F7EA861135C021A35FD26B6C79
    [mdOrder] => 7a4bff04-dae1-7711-82b8-137e01edca78
    [orderDescription] => %D0%A8%D0%B8%D1%85%D0%B0%D0%BD%D0%BE%D0%B2%D0%B0
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: f8b53c4b784de6fa0cd00a9b2f24094fa15ede31fc48c8713d1fb4b0711b41bc
Date: 2022-08-15 14:10:04

Array
(
    [amount] => 1950000
    [orderNumber] => 204002
    [checksum] => F8B53C4B784DE6FA0CD00A9B2F24094FA15EDE31FC48C8713D1FB4B0711B41BC
    [mdOrder] => 450e6351-c3a7-74cf-a241-8e8601edca78
    [orderDescription] => GURU%2C+%D0%BF%D0%B5%D1%80%D0%B5%D1%85%D0%BE%D0%B4%D0%BD%D0%B8%D0%BA+%D0%B0%D0%BB+16
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 0f48de47c50e0c3a854faf690f481151543a1ed3dc67c7d2751dcf99424dc7b7
Date: 2022-08-17 13:40:02

Array
(
    [amount] => 1620000
    [orderNumber] => 205000
    [checksum] => 0F48DE47C50E0C3A854FAF690F481151543A1ED3DC67C7D2751DCF99424DC7B7
    [mdOrder] => 16625478-1169-78fc-818b-749b01edca78
    [orderDescription] => GURU%2C+%D1%84%D1%82%D0%BE%D1%80%D0%BE%D0%BF%D0%BB+%D0%B1%D0%B5%D0%BB+3
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 00f50c94f76c3f5c27fe0542190559eab72dec7644dee6327adf1012dfceb80b
Date: 2022-08-17 18:56:26

Array
(
    [amount] => 200000
    [orderNumber] => 205001
    [checksum] => 00F50C94F76C3F5C27FE0542190559EAB72DEC7644DEE6327ADF1012DFCEB80B
    [mdOrder] => 04595c64-ee46-7182-baff-d69201edca78
    [orderDescription] => %D0%A8%D0%BD%D1%83%D1%80+%D0%9B%D0%BE%D0%B2%D0%B8
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 9c7e31f8d0eebb573876d58d18ec5032ffa8aebc1736bc590bd714264462741a
Date: 2022-08-18 15:46:34

Array
(
    [amount] => 200000
    [orderNumber] => 206000
    [checksum] => 9C7E31F8D0EEBB573876D58D18EC5032FFA8AEBC1736BC590BD714264462741A
    [mdOrder] => 405f6bcb-891a-7703-9371-511301edca78
    [orderDescription] => %D0%A8%D0%BD%D1%83%D1%80+Lovi%2CG%2C+R
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 5baace639acca626142eb4ea1bf6e5f4490c16682bb4b6990d0e875357dd275c
Date: 2022-08-19 07:31:29

Array
(
    [amount] => 5100000
    [orderNumber] => 207000
    [checksum] => 5BAACE639ACCA626142EB4EA1BF6E5F4490C16682BB4B6990D0E875357DD275C
    [mdOrder] => 76bcdecb-35d0-72a2-bdea-b51001edca78
    [orderDescription] => REY%2C+%D0%A5%D0%B5%D0%BB%D0%BF%D0%B5%D1%80+%D0%B416%2C+%D0%B3%D1%80%D0%BE%D0%BC%D0%B5%D1%82%D1%81%D1%8B%2C+%D1%80%D0%B5%D0%B7%D0%B8%D0%BD%D0%BA%D0%B8
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: c6abdcafd3665aeae3b06cabf745a76111b8a982fccc6ab5447a32de6af3f847
Date: 2022-08-19 15:38:20

Array
(
    [amount] => 100
    [orderNumber] => 208000
    [checksum] => C6ABDCAFD3665AEAE3B06CABF745A76111B8A982FCCC6AB5447A32DE6AF3F847
    [mdOrder] => d7181f1b-7e89-7fd7-8021-cd2101edca78
    [orderDescription] => %D0%9E%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%B8%D0%B5+%D0%B4%D0%BB%D1%8F+%D0%BA%D0%BB%D0%B8%D0%B5%D0%BD%D1%82%D0%B0
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 892c11916e359c3c318cf6d0ed8cff9f4c64b80c72309ff9087808a80aaf1dfe
Date: 2022-08-21 17:22:50

Array
(
    [amount] => 200000
    [orderNumber] => 208001
    [checksum] => 892C11916E359C3C318CF6D0ED8CFF9F4C64B80C72309FF9087808A80AAF1DFE
    [mdOrder] => 21db3f57-fa5f-7d3e-a840-247e01edca78
    [orderDescription] => %D0%91%D0%B0%D1%80
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 03bba1cb265e1d148e7eadda733d285b2ffcad5ac9059d94d655f6da6f5a0302
Date: 2022-08-21 19:18:24

Array
(
    [amount] => 1500000
    [orderNumber] => 207001
    [checksum] => 03BBA1CB265E1D148E7EADDA733D285B2FFCAD5AC9059D94D655F6DA6F5A0302
    [mdOrder] => 4b0882c5-bdd9-72f5-a2f0-c98f01edca78
    [orderDescription] => Guru_%D0%9D%D0%BE%D0%B2%D0%B8%D0%BD%D1%81%D0%BA%D0%B0%D1%8F
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: c70c7c95e25d455e7453a06a9a9700fcdf820f5ebdee6d5a036ea677b2c8c9e2
Date: 2022-08-22 06:15:14

Array
(
    [amount] => 200000
    [orderNumber] => 209000
    [checksum] => C70C7C95E25D455E7453A06A9A9700FCDF820F5EBDEE6D5A036EA677B2C8C9E2
    [mdOrder] => 6e8703e6-8069-7255-87aa-d0da01edca78
    [orderDescription] => %D0%A8%D0%BD%D1%83%D1%80+Lovi
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 1df6beb9e0398730866dd11ed87d39164cb1645badc51b12799eaf2566706429
Date: 2022-08-22 09:55:57

Array
(
    [amount] => 50000
    [orderNumber] => 209001
    [checksum] => 1DF6BEB9E0398730866DD11ED87D39164CB1645BADC51B12799EAF2566706429
    [mdOrder] => c78950a3-b253-71ce-a286-1c8601edca78
    [orderDescription] => %D0%A0%D0%B5%D0%B7%D0%B8%D0%BD%D0%BA%D0%B8
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 060b18e13f55f771dfb2d34923f38a3c954b7a1c5d175e74b484a6cfc6878278
Date: 2022-08-22 16:06:49

Array
(
    [amount] => 1565000
    [orderNumber] => 208002
    [checksum] => 060B18E13F55F771DFB2D34923F38A3C954B7A1C5D175E74B484A6CFC6878278
    [mdOrder] => 91d3e4f5-d97c-7ef7-a758-917e01edca78
    [orderDescription] => Guru%2C+%D1%80%D0%B5%D0%B7%D0%B8%D0%BD%D0%BA%D0%B8%2C+%D1%82%D0%BE%D0%BB%D0%BA%D0%B0%D1%82%D0%B5%D0%BB%D1%8C
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 65263c449df2cce00a1ea6c48b94f0f73d94ba138cf82be2771f0f55370eadf6
Date: 2022-08-22 21:25:08

Array
(
    [amount] => 750000
    [orderNumber] => 210000
    [checksum] => 65263C449DF2CCE00A1EA6C48B94F0F73D94BA138CF82BE2771F0F55370EADF6
    [mdOrder] => 8d6a95c4-8016-7733-bc61-9f5501edca78
    [orderDescription] => %D0%A6%D0%B0%D0%BD%D0%B3%D0%B0%2C+%D0%BA%D0%BB%D1%8E%D1%87+1.5%2C+%D0%A8%D0%BD%D1%83%D1%80+%D0%9B%2C+%D0%A5%D0%B5%D0%BF%D0%BB+%D0%B418
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: b31b882755a533056fcf34d8f7bb222fd317ba5f75610b2d2fc79cb68f60af03
Date: 2022-08-23 08:50:22

Array
(
    [amount] => 500000
    [orderNumber] => 211000
    [checksum] => B31B882755A533056FCF34D8F7BB222FD317BA5F75610B2D2FC79CB68F60AF03
    [mdOrder] => 0727b77c-41cc-7bce-aac4-a92601edca78
    [orderDescription] => %D0%A5%D0%B5%D0%BB%D0%BF%D0%B5%D1%80
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 1c1bced8b5324d91d733ae82072638ae1a34f29d03de3cb4a3abf6f56ef3d840
Date: 2022-08-23 18:10:57

Array
(
    [amount] => 2100000
    [orderNumber] => 212000
    [checksum] => 1C1BCED8B5324D91D733AE82072638AE1A34F29D03DE3CB4A3ABF6F56EF3D840
    [mdOrder] => 59477c4e-9901-7638-813e-1a1401edca78
    [orderDescription] => ALTERA
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 4991b00b4beb076997691230d7a79c224b46ca936a3ecf33e02192bdb6aa3006
Date: 2022-08-24 08:39:45

Array
(
    [amount] => 350000
    [orderNumber] => 213000
    [checksum] => 4991B00B4BEB076997691230D7A79C224B46CA936A3ECF33E02192BDB6AA3006
    [mdOrder] => fa354eb7-16fc-764c-a819-569e01edca78
    [orderDescription] => 1R0.3%2C+%D1%80%D0%B5%D0%B7%D0%B8%D0%BD%D0%BA%D0%B8
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 78d8b231e7a2ffbf0c7417e8324418a343730551dbc929f7518fce384a067a60
Date: 2022-08-24 16:43:06

Array
(
    [amount] => 650000
    [orderNumber] => 212001
    [checksum] => 78D8B231E7A2FFBF0C7417E8324418A343730551DBC929F7518FCE384A067A60
    [mdOrder] => 550800d9-29b8-76b8-a08a-698701edca78
    [orderDescription] => %D0%A8%D0%BD%D1%83%D1%80+%D0%9B%D0%9E%D0%B2%D0%B8+%D1%854
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: ac97abf5a74adaef992e55ac0812bd564e298c946d9747434bad256020b4fe9a
Date: 2022-08-25 13:28:28

Array
(
    [amount] => 200000
    [orderNumber] => 214000
    [checksum] => AC97ABF5A74ADAEF992E55AC0812BD564E298C946D9747434BAD256020B4FE9A
    [mdOrder] => 05ecc054-a831-74c1-b45b-842e01edca78
    [orderDescription] => %D0%A8%D0%BD%D1%83%D1%80+%D0%9B%D0%BE%D0%B2%D0%B8
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: 908de5aca604706ffbddcaa248b11c624c55f1727240d90ad38d85a19b033818
Date: 2022-08-25 22:13:32

Array
(
    [amount] => 2415000
    [orderNumber] => 213001
    [checksum] => 908DE5ACA604706FFBDDCAA248B11C624C55F1727240D90AD38D85A19B033818
    [mdOrder] => 4153f63b-b95f-78c8-8daf-6e7801edca78
    [orderDescription] => Guru
    [operation] => deposited
    [status] => 1
)


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Checksum: aadbd9532390a0cebc2e51795ebed377e278eb10482f71b4f750bd595617fa08
Date: 2022-08-26 17:59:41

Array
(
    [amount] => 160000
    [orderNumber] => 212002
    [checksum] => AADBD9532390A0CEBC2E51795EBED377E278EB10482F71B4F750BD595617FA08
    [mdOrder] => 1fe61449-ee5f-7a40-a82c-ad3301edca78
    [orderDescription] => %D0%A4%D1%82%D0%BE%D1%80%D0%BE%D0%BF%D0%BB%D0%B0%D1%81%D1%82+%D1%87%D0%B5%D1%80%D0%BD
    [operation] => deposited
    [status] => 1
)


